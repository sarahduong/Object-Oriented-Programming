package sd7mygpacalculatorf20;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class Sd7myGPACalculatorF20 extends Application 
{    
    public String fontStyle = "Arial";
    double calcScore;
    int numOfScores = 4;
    String finalScore;

    @Override
    public void start(Stage primaryStage) 
    {
        GridPane root = new GridPane();
        root.setAlignment(Pos.BASELINE_CENTER);
        root.setPadding(new Insets(10, 0, 10, 0));
        root.setHgap(8);
        root.setVgap(8);
        
        Label course1 = new Label("Course 1: ");
        course1.setFont(Font.font(fontStyle, FontWeight.NORMAL, 14));
        root.add(course1, 0, 0);
        Label course2 = new Label("Course 2: ");
        course2.setFont(Font.font(fontStyle, FontWeight.NORMAL, 14));
        root.add(course2, 0, 1);       
        Label course3 = new Label("Course 3: ");
        course3.setFont(Font.font(fontStyle, FontWeight.NORMAL, 14));
        root.add(course3, 0, 2);        
        Label course4 = new Label("Course 4: ");
        course4.setFont(Font.font(fontStyle, FontWeight.NORMAL, 14));
        root.add(course4, 0, 3);        
        Label finalGPA = new Label("Final GPA: ");
        finalGPA.setFont(Font.font(fontStyle, FontWeight.NORMAL, 14));
        root.add(finalGPA, 0, 4);
        
        TextField score1 = new TextField();
        score1.setPrefWidth(300);
        root.add(score1, 1, 0);
        
        TextField score2 = new TextField();
        score2.setPrefWidth(300);
        root.add(score2, 1, 1);
        
        TextField score3 = new TextField();
        score3.setPrefWidth(300);
        root.add(score3, 1, 2);
        
        TextField score4 = new TextField();
        score4.setPrefWidth(300);
        root.add(score4, 1, 3);
        
        TextArea finalScore = new TextArea();
        finalScore.setPrefWidth(300);
        finalScore.setPrefRowCount(2);
        finalScore.setWrapText(true);
        finalScore.setEditable(false);
        root.add(finalScore, 1, 4);
        
        Button emButton = new Button("Emulate GPA");
        root.add(emButton, 0 , 6);
        emButton.setOnAction(new EventHandler<ActionEvent>()
        {
            @Override
            public void handle(ActionEvent e) 
            {            
                try
                {               
                    TextInputDialog textBox = new TextInputDialog();
                    textBox.setTitle("GPA");
                    textBox.setHeaderText("Calculate Desired GPA");
                    textBox.setContentText("Please enter your desired GPA (0-4): ");
                    textBox.showAndWait();
                    
                    // int checking
                    int w = Integer.parseInt(textBox.getEditor().getText());

                    int getField = Integer.valueOf(textBox.getEditor().getText());
                    if(getField == 0 || getField == 1 || getField == 2 || getField == 3 || getField == 4)
                    {
                        score1.setText("");
                        score2.setText("");
                        score3.setText("");
                        score4.setText("");

                        if(getField == 0)
                        {
                            finalScore.setText("Minimum grade needed is 0 for 0 GPA."); 
                        }
                        if(getField == 1)
                        {
                            finalScore.setText("Minimum grade needed is 63 for 1 GPA.");
                        }
                        if(getField == 2)
                        {
                            finalScore.setText("Minimum grade needed is 73 for 2 GPA.");                        
                        }
                        if(getField == 3)
                        {
                            finalScore.setText("Minimum grade needed is 83 for 3 GPA.");                        
                        }
                        if(getField == 4)
                        {
                            finalScore.setText("Minimum grade needed is 100 for 4 GPA.");                        
                        }
                    } 
                    else
                    {
                        finalScore.setText("Not valid. Please enter an integer between 0-4.");                        
                    }
                }
                catch(NumberFormatException ex)
                {
                    finalScore.setText("Not valid. Please enter an integer between 0-4.");
                }
            }
        });

        Button gpaButton = new Button("Calculate GPA");
        root.add(gpaButton, 0 , 7);
        gpaButton.setOnAction(new EventHandler<ActionEvent>()
        {
            @Override
            public void handle(ActionEvent e) 
            {            
                if(score1.getText().isEmpty() || score2.getText().isEmpty() || score4.getText().isEmpty() || score4.getText().isEmpty())
                {
                    Alert a = new Alert(AlertType.INFORMATION);
                    a.setContentText("Please enter a score for all courses!");
                    a.show();
                }
                try
                {
                    // int checking
                    int w = Integer.parseInt(score1.getText());
                    int x = Integer.parseInt(score2.getText());
                    int y = Integer.parseInt(score3.getText());
                    int z = Integer.parseInt(score4.getText());
                        
                    // conv to double
                    double SCORE1 = Double.valueOf(score1.getText());
                    double SCORE2 = Double.valueOf(score2.getText());
                    double SCORE3 = Double.valueOf(score3.getText());
                    double SCORE4 = Double.valueOf(score4.getText());

                    double calcScore = (((SCORE1 + SCORE2 + SCORE3 + SCORE4)/4)/100);
                
                    if(SCORE1 < 0 || SCORE1 > 100 || SCORE2 < 0 || SCORE2 > 100 || SCORE3 < 0 || SCORE3 > 100 || SCORE4 < 0 || SCORE4 > 100 )
                    {
                        finalScore.setText("Please enter a value between 0 to 100.");
                    }
                    else
                    {
                        String FS = "";
                        if(calcScore >= 0.98)
                            FS = "A+";
                        if(calcScore >= 0.93 && calcScore < 0.98)
                            FS = "A";
                        if(calcScore >= 0.90 && calcScore < 0.93)
                            FS = "A-";
                        if(calcScore >= 0.88 && calcScore < 0.90)
                            FS = "B+";
                        if(calcScore >= 0.83 && calcScore < 0.88)
                            FS = "B";
                        if(calcScore >= 0.80 && calcScore < 0.83)
                            FS = "B-";
                        if(calcScore >= 0.78 && calcScore < 0.80)
                            FS = "C+";
                        if(calcScore >= 0.73 && calcScore < 0.78)
                            FS = "C";
                        if(calcScore >= 0.70 && calcScore < 0.73)
                            FS = "C-";
                        if(calcScore >= 0.68 && calcScore < 0.70)
                            FS = "D+";
                        if(calcScore >= 0.63 && calcScore < 0.68)
                            FS = "D";
                        if(calcScore >= 0.59 && calcScore < 0.63)
                            FS = "D-";
                        if(calcScore <= 0.59)
                            FS = "F";

                        System.out.printf("FS: %s\n", FS);
                        finalScore.setText("My final score should be (((");
                        finalScore.appendText(SCORE1 + " + " + SCORE2 + " + " + SCORE3 + " + " + SCORE4);
                        finalScore.appendText(")/4)/100) = " + FS);  

                        // bonus alert message
                        if(calcScore >= 0.93 && calcScore < 1.01)
                        {
                            Alert alert = new Alert(AlertType.INFORMATION);
                            alert.setHeaderText("YOU DID IT!!!");
                            alert.setContentText("Congratulations, you got an A+/A!");
                            alert.show();
                        }     
                    }
                }
                catch(NumberFormatException ex)
                {
                    finalScore.setText("Please ensure all scores are between 0 and 100.");
                }
            }
        });
        
        Button clearButton = new Button("Clear All");
        root.add(clearButton, 0 , 8);    
        clearButton.setOnAction(new EventHandler<ActionEvent>()
        {
            @Override
            public void handle(ActionEvent e) 
            {
                score1.setText("");
                score2.setText("");
                score3.setText("");
                score4.setText("");
                finalScore.setText("");     
            }
        });

        Button alertButton = new Button("Alert");
        root.add(alertButton, 0 , 9);    
        alertButton.setOnAction(new EventHandler<ActionEvent>()
        {
            @Override
            public void handle(ActionEvent e) 
            {
                if(finalScore.getText().isEmpty())
                {
                    Alert alert = new Alert(AlertType. ERROR);
                    alert.setContentText("Please calculate a GPA first!");
                    alert.show();
                }
                else
                {
                    // adapted from https://code.makery.ch/blog/javafx-dialogs-official/
                    Alert a = new Alert(AlertType.INFORMATION);
                    a.setContentText(finalScore.getText());

                    a.show(); 
                }
            }
        });

        VBox vbox = new VBox(10);
        root.add(vbox, 0, 5, 2, 1);
        vbox.setMaxWidth(Double.MAX_VALUE);
        emButton.setMaxWidth(Double.MAX_VALUE);
        gpaButton.setMaxWidth(Double.MAX_VALUE);
        clearButton.setMaxWidth(Double.MAX_VALUE);
        alertButton.setMaxWidth(Double.MAX_VALUE);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPadding(new Insets(10, 0, 10, 0));
        vbox.setSpacing(15);
        vbox.getChildren().add(emButton);
        vbox.getChildren().add(gpaButton);
        vbox.getChildren().add(clearButton);
        vbox.getChildren().add(alertButton);        
        
        Scene scene = new Scene(root, 400, 400);
        
        primaryStage.setTitle("GPA Calculator");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) { 
        launch(args);
    }
}
