package sd7mymoviesf20;

public enum Category 
{
    ACTION, COMEDY, DRAMA, FANTASY, HORROR, ROMANCE, WESTERN, SCI_FI, SUSPENSE, ANIMATION, UNKNOWN
};